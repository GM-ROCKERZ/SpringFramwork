package com.luv2code.springdemo;

import org.springframework.stereotype.Component;

@Component("thatSillyCoach")
public class TenniesCoach implements Coach {

	@Override
	public String getDailyWorkout() {

		return "practice your backhand volley";
	}

}
